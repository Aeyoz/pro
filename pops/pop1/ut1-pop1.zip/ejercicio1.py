# ut1-pop1-ej1
a = 5
b = 7
# No tocar nada de aquí hacia arriba ↑
# ********************************************************

# ========================================================
# @@ Escribe tu código debajo de esta línea ↓

F = a ** 2 + b ** 2 - (a * b) ** 0.5

# $$ Escribe tu código encima de esta línea ↑
# ========================================================

# ********************************************************
# No tocar nada de aquí hacia abajo ↓
assert F == 68.08392021690038